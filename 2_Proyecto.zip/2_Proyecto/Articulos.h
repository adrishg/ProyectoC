#ifndef _ARTICULOS_H_
#define _ARTICULOS_H_

	void accionArticulos();
	void AgregarArticulos();
	void EliminarArticulos();

#endif