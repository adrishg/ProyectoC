#ifndef _DEPARTAMENTOS_H_
#define _DEPARTAMENTOS_H_

void accionDepartamentos();
void AgregarDepartamentos();
void EliminarDepartamentos();

#endif