#ifndef _ADMINISTRADORGENERAL_H_
#define _ADMINISTRADORGENERAL_H_

int administradorGeneral(char buffer[100]);
void AdministradorAccion();

#endif