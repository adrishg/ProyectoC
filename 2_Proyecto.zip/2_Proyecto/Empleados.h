#ifndef _EMPLEADOS_H_
#define _EMPLEADOS_H_

	void accionEmpleados();
	void AgregarEmpleados();
	void EliminarEmpleados();
	void ModificarEmpleados();

#endif