#ifndef _EMPLEADOCOMPRAS_H_
#define _EMPLEADOCOMPRAS_H_

int empleadoCompras(char buffer[100]);
void empleadoComprasAccion();

#endif