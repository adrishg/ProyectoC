#ifndef _EMPLEADOVENTAS_H_
#define _EMPLEADOVENTAS_H_

int empleadoVentas(char buffer[100]);
void empleadoVentasAccion();

#endif